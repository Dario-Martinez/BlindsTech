#!/bin/bash
source "ejercicio5.bash"
cat /var/log/mis/respaldos

loguear_ejecucion_de_script
